using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using EkspresKawyWPF.Models;

namespace EkspresKawyWPF.Models
{
    public class Ekspres
    {
        public List<Skladnik> Skladniki { get; private set; }
        public List<Napoj> Napoje { get; private set; }
        public List<string> Historia { get; private set; }
        private TrybCzyszczenia trybCzyszczenia;
        private int licznikNapoje = 0;
        private int licznikFusy = 0;

        public bool CzyGrzany { get; private set; } = false;

        public Ekspres()
        {
            Skladniki = new List<Skladnik>
            {
                new Skladnik("Woda", 1000, 1000),
                new Skladnik("Kawa", 200, 200),
                new Skladnik("Mleko", 500, 500),
                new Skladnik("Cukier", 100, 100),
                new Skladnik("Herbata", 100, 100),
                new Skladnik("Kakao", 100, 100)
            };

            Napoje = new List<Napoj>
            {
                new Napoj("Espresso", new Dictionary<string, int>{{"Woda", 50}, {"Kawa", 10}}),
                new Napoj("Cappuccino", new Dictionary<string, int>{{"Woda", 50}, {"Kawa", 10}, {"Mleko", 50}}),
                new Napoj("Latte", new Dictionary<string, int>{{"Woda", 50}, {"Kawa", 10}, {"Mleko", 100}}),
                new Napoj("Kawa czarna", new Dictionary<string, int>{{"Woda", 100}, {"Kawa", 15}}),
                new Napoj("Herbata", new Dictionary<string, int>{{"Woda", 200}, {"Herbata", 5}}),
                new Napoj("Kakao", new Dictionary<string, int>{{"Woda", 150}, {"Mleko", 50}, {"Kakao", 10}, {"Cukier", 5}})
            };

            Historia = new List<string>();
            trybCzyszczenia = new TrybCzyszczenia();
        }



        public string PrzygotujNapoj(int index)
        {
            if (index < 0 || index >= Napoje.Count)
                return "Nieprawid�owy numer napoju.";

            var napoj = Napoje[index];

            // Sprawdzenie sk�adnik�w
            foreach (var wymagany in napoj.WymaganeSkladniki)
            {
                var skladnik = Skladniki.FirstOrDefault(s => s.Nazwa == wymagany.Key);
                if (skladnik == null || skladnik.Ilosc < wymagany.Value)
                    return $"Brak wystarczaj�cej ilo�ci: {wymagany.Key}";
            }

            // Zu�ycie sk�adnik�w
            foreach (var wymagany in napoj.WymaganeSkladniki)
            {
                var skladnik = Skladniki.First(s => s.Nazwa == wymagany.Key);
                skladnik.Ilosc -= wymagany.Value;
            }

            licznikNapoje++;
            licznikFusy++;
            Historia.Add(napoj.Nazwa);

            if (licznikNapoje % 3 == 0)
                Czysc();

            if (licznikFusy >= 10)
                return "UWAGA! Pojemnik na fusy jest pe�ny. Opr�nij pojemnik przed kolejnym napojem.";

            return $"Przygotowano: {napoj.Nazwa}";
        }



        public string Czysc()
        {
            licznikFusy = 0;
            return trybCzyszczenia.Uruchom();
        }

        public void UzupelnijSkladnik(int index, int ilosc)
        {
            if (index < 0 || index >= Skladniki.Count)
                return;
            var s = Skladniki[index];
            s.Ilosc += ilosc;
            if (s.Ilosc > s.MaxIlosc)
                s.Ilosc = s.MaxIlosc;
        }

        public void UzupelnijSkladnik(string nazwa, int ilosc)
        {
            var skladnik = Skladniki.FirstOrDefault(s => s.Nazwa == nazwa);
            if (skladnik != null)
            {
                skladnik.Ilosc = Math.Min(skladnik.Ilosc + ilosc, skladnik.MaxIlosc);
            }
        }

        public void UzupelnijWszystko()
        {
            foreach (var s in Skladniki)
                s.UzupelnijDoPelna();
        }

        public void OproznijFusy()
        {
            licznikFusy = 0;
        }

        public async Task GrzanieAsync()
        {
            CzyGrzany = true;
            await Task.Delay(20000); 
            CzyGrzany = false;
        }
    }
}
