﻿using EkspresKawyWPF.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class SkladnikTests
    {
        [TestMethod]
        public void Konstruktor_UstawiaWlasciwosciPoprawnie()
        {
            // Arrange
            string nazwa = "Kawa";
            int ilosc = 10;
            int maxIlosc = 20;

            // Act
            var skladnik = new Skladnik(nazwa, ilosc, maxIlosc);

            // Assert
            Assert.AreEqual(nazwa, skladnik.Nazwa);
            Assert.AreEqual(ilosc, skladnik.Ilosc);
            Assert.AreEqual(maxIlosc, skladnik.MaxIlosc);
        }

        [TestMethod]
        public void UzupelnijDoPelna_UstawiaIloscNaMaxIlosc()
        {
            // Arrange
            var skladnik = new Skladnik("Mleko", 5, 15);

            // Act
            skladnik.UzupelnijDoPelna();

            // Assert
            Assert.AreEqual(15, skladnik.Ilosc);
        }
    }
}