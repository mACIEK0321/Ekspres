using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace EkspresKawyWPF.Models
{
    public class WyborNapojDialog : Window
    {
        public int WybranyIndex { get; private set; } = -1;

        public WyborNapojDialog(List<string> napoje)
        {
            Title = "Wybierz nap�j";
            Width = 300;
            Height = 250;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;

            var stack = new StackPanel();
            var listBox = new ListBox { ItemsSource = napoje, Margin = new Thickness(10), Height = 120 };
            var btnWybierz = new Button { Content = "Wybierz", Margin = new Thickness(10) };
            btnWybierz.IsEnabled = false;

            listBox.SelectionChanged += (s, e) =>
            {
                btnWybierz.IsEnabled = listBox.SelectedIndex >= 0;
            };

            btnWybierz.Click += (s, e) =>
            {
                WybranyIndex = listBox.SelectedIndex;
                DialogResult = true;
                Close();
            };

            stack.Children.Add(listBox);
            stack.Children.Add(btnWybierz);
            Content = stack;
        }
    }
}