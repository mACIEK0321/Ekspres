using System.Collections.Generic;

namespace EkspresKawyWPF.Models
{
    public class Napoj
    {
        public string Nazwa { get; set; }
        public Dictionary<string, int> WymaganeSkladniki { get; set; }

        public Napoj(string nazwa, Dictionary<string, int> wymaganeSkladniki)
        {
            Nazwa = nazwa;
            WymaganeSkladniki = wymaganeSkladniki;
        }
    }
}