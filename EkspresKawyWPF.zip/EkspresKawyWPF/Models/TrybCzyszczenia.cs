using System.Threading;

namespace EkspresKawyWPF.Models
{
    public class TrybCzyszczenia
    {
        public string Uruchom()
        {
            Thread.Sleep(2000);
            return "Czyszczenie zako�czone!";
        }
    }
}