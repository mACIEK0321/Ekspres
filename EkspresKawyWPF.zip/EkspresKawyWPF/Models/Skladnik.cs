namespace EkspresKawyWPF.Models
{
    public class Skladnik
    {
        public string Nazwa { get; set; }
        public int Ilosc { get; set; }
        public int MaxIlosc { get; set; }

        public Skladnik(string nazwa, int ilosc, int maxIlosc)
        {
            Nazwa = nazwa;
            Ilosc = ilosc;
            MaxIlosc = maxIlosc;
        }

        public void UzupelnijDoPelna()
        {
            Ilosc = MaxIlosc;
        }
    }
}