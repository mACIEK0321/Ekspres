﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using EkspresKawyWPF.Models;

namespace EkspresKawyWPF
{
    public partial class MainWindow : Window
    {
        private Ekspres ekspres;               // Obiekt reprezentujący ekspres do kawy
        private int licznikNapoje = 0;         // Licznik zrobionych napojów 

        public MainWindow()
        {
            InitializeComponent();              // Inicjalizacja komponentów UI
            UstawDostepnoscPrzyciskow(false);  // Na start blokujemy przyciski (np. do przygotowania napoju)
            StatusLabel.Text = "Grzanie Ekspresu";  
            Loaded += MainWindow_LoadedAsync;  // Podpinamy asynchroniczną metodę po załadowaniu okna
        }

        // Metoda asynchroniczna wywoływana po załadowaniu okna
        private async void MainWindow_LoadedAsync(object sender, RoutedEventArgs e)
        {
            await Task.Delay(2000);
            ekspres = new Ekspres();
            OdswiezWyswietlacz();
            StatusLabel.Text = "Grzanie zakończone!";
            UstawDostepnoscPrzyciskow(true);
        }
        // Metoda do ustawiania dostępności panelu z przyciskami (blokowanie/odblokowanie)
        private void UstawDostepnoscPrzyciskow(bool dostepne)
        {
            PrzyciskiPanel.IsEnabled = dostepne;
        }

        // Obsługa kliknięcia przycisku: pokazuje listę składników ekspresu (z aktualnymi stanami)
        private void PokazSkladniki_Click(object sender, RoutedEventArgs e)
        {
            ListaWynikow.Items.Clear();           
            foreach (var s in ekspres.Skladniki) 
                ListaWynikow.Items.Add(s.Nazwa + ": " + s.Ilosc + "/" + s.MaxIlosc);
        }

        // Obsługa kliknięcia przycisku: pokazuje listę napojów dostępnych w ekspresie
        private void PokazNapoje_Click(object sender, RoutedEventArgs e)
        {
            ListaWynikow.Items.Clear();           
            int i = 1;
            foreach (var n in ekspres.Napoje)   
                ListaWynikow.Items.Add($"{i++}. {n.Nazwa}");
        }

        // Obsługa kliknięcia przycisku: przygotowuje wybrany napój
        private async void PrzygotujNapoj_Click(object sender, RoutedEventArgs e)
        {
            if (ekspres.Napoje.Count == 0)      
            {
                MessageBox.Show("Brak napojów."); 
                return;
            }

            // Tworzymy okno dialogowe do wyboru napoju, przekazując listę nazw napojów
            var dialog = new WyborNapojDialog(ekspres.Napoje.Select(n => n.Nazwa).ToList());

            if (dialog.ShowDialog() == true)    
            {
                int nr = dialog.WybranyIndex;   // Pobieramy indeks wybranego napoju
                ListaWynikow.Items.Clear();

               
                StatusLabel.Text = "Rozpoczynanie przygotowania napoju...";
                ListaWynikow.Items.Add("Rozpoczynanie przygotowania napoju...");
                await Task.Delay(1500);

                StatusLabel.Text = "Mielenie kawy...";
                ListaWynikow.Items.Add("Mielenie kawy...");
                await Task.Delay(2000);

                StatusLabel.Text = "Podgrzewanie wody...";
                ListaWynikow.Items.Add("Podgrzewanie wody...");
                await Task.Delay(2000);

                StatusLabel.Text = "Parzenie kawy...";
                ListaWynikow.Items.Add("Parzenie kawy...");
                await Task.Delay(3000);

                StatusLabel.Text = "Kończenie procesu...";
                ListaWynikow.Items.Add("Kończenie procesu...");
                await Task.Delay(1500);

                // Wywołujemy metodę przygotowania napoju, która zwraca komunikat
                string komunikat = ekspres.PrzygotujNapoj(nr);
                ListaWynikow.Items.Add(komunikat);
                StatusLabel.Text = "Napój gotowy!";

                OdswiezWyswietlacz();          // Odświeżamy wyświetlane składniki (zmniejszają się po użyciu)

                licznikNapoje++;              

                if (licznikNapoje >= 3)       
                {
                    await Task.Delay(1000);
                    StatusLabel.Text = "Automatyczne czyszczenie ekspresu...";
                    ListaWynikow.Items.Add("Automatyczne czyszczenie ekspresu...");
                    await Task.Delay(2000);

                    string czyszczenieKomunikat = ekspres.Czysc();
                    ListaWynikow.Items.Add(czyszczenieKomunikat);

                    StatusLabel.Text = "Ekspres wyczyszczony! Opróżnij pojemnik na fusy i brudną wodę.";

                    MessageBox.Show("Ekspres został automatycznie wyczyszczony!\nOpróżnij pojemnik na fusy i brudną wodę, a następnie kliknij OK, aby kontynuować.",
                        "Czyszczenie ekspresu", MessageBoxButton.OK, MessageBoxImage.Information);

                    licznikNapoje = 0;         
                    StatusLabel.Text = "Ekspres gotowy do pracy.";
                }
            }
        }

        // Obsługa kliknięcia przycisku: ręczne czyszczenie ekspresu
        private void Czysc_Click(object sender, RoutedEventArgs e)
        {
            ListaWynikow.Items.Clear();
            ListaWynikow.Items.Add(ekspres.Czysc());   
            OdswiezWyswietlacz();                       
        }

        // Obsługa kliknięcia przycisku: uzupełnia wszystkie składniki do pełna
        private void UzupelnijSkladniki_Click(object sender, RoutedEventArgs e)
        {
            ekspres.UzupelnijWszystko();                
            ListaWynikow.Items.Clear();
            ListaWynikow.Items.Add("Wszystkie składniki zostały uzupełnione do pełna!");
            OdswiezWyswietlacz();                      
        }

        // Metoda odświeżająca wyświetlane dane o składnikach w liście i ComboBoxie
        private void OdswiezWyswietlacz()
        {
            StanSkladnikow.ItemsSource = null;          
            StanSkladnikow.ItemsSource = ekspres.Skladniki;  // Ustawiamy aktualną listę składników

            SkladnikComboBox.ItemsSource = null;        
            SkladnikComboBox.ItemsSource = ekspres.Skladniki;  // Ustawiamy aktualną listę składników
        }

        // Uzupełnianie pojedynczego wybranego składnika (lista składników)
        private void UzupelnijWybranySkladnik_Click(object sender, RoutedEventArgs e)
        {
            if (StanSkladnikow.SelectedItem is Skladnik wybranySkladnik)  // Sprawdzamy, czy coś jest wybrane
            {

                var input = IloscTextBox.Text;

                if (int.TryParse(input, out int ilosc) && ilosc > 0)
                {
                    ekspres.UzupelnijSkladnik(wybranySkladnik.Nazwa, ilosc);  
                    OdswiezWyswietlacz();                                    
                    MessageBox.Show($"Uzupełniono składnik: {wybranySkladnik.Nazwa} o {ilosc} jednostek.");
                }
                else
                {
                    MessageBox.Show("Podano nieprawidłową ilość.");           
                }
            }
            else
            {
                MessageBox.Show("Wybierz składnik z listy.");               
            }
        }

        // Uzupełnianie pojedynczego wybranego składnika przez ComboBox i TextBox (ilość wpisana ręcznie)
        private void UzupelnijWybranyCombo_Click(object sender, RoutedEventArgs e)
        {
            if (SkladnikComboBox.SelectedItem is Skladnik wybranySkladnik)  
            {
                if (int.TryParse(IloscTextBox.Text, out int ilosc) && ilosc > 0)
                {
                    ekspres.UzupelnijSkladnik(wybranySkladnik.Nazwa, ilosc);  
                    OdswiezWyswietlacz();                                     
                    MessageBox.Show($"Uzupełniono składnik: {wybranySkladnik.Nazwa} o {ilosc} jednostek.");
                }
                else
                {
                    MessageBox.Show("Podano nieprawidłową ilość.");          
                }
            }
            else
            {
                MessageBox.Show("Wybierz składnik z listy.");              
            }
        }

        // Pokazuje historię przygotowanych napojów w liście wyników
        private void PokazHistorie_Click(object sender, RoutedEventArgs e)
        {
            ListaWynikow.Items.Clear();
            if (ekspres.Historia != null && ekspres.Historia.Count > 0)
            {
                ListaWynikow.Items.Add("Historia przygotowanych napojów:");
                foreach (var wpis in ekspres.Historia)
                    ListaWynikow.Items.Add(wpis);
            }
            else
            {
                ListaWynikow.Items.Add("Brak historii napojów.");  
            }
        }
    }
}
